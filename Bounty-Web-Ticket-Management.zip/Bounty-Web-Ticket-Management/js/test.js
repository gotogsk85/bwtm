angular.module("test",["ngRoute"])

.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "login.html",
        controller : "loginCtrl"
    })
    .when("/admin", {
        templateUrl : "admin.html",
        controller: "adminCtrl"
    })
    .when("/user", {
        templateUrl : "user.html",
        controller: "userCtrl"
    })

})

.service("localStorageSvc", function(){

		this.setLoggedInUserId = function(c){
			this.loggedInUserId = c;
		}

		this.getLoggedInUserId = function(){
			return this.loggedInUserId;
		}

		this.setAdminData = function(){
			var bwts = this.getData();
			if(bwts == null){
				bwts = {"users": {"1": {type: "admin", uname: "admin", pwd: "admin"}}};
				this.userid = 1;
				this.setData(bwts);			
			}
		}

		this.createNewUser = function(obj){
			this.userId = this.userId + 1;
			var bwts = this.getData();
			bwts["users"][this.userId] = {type: obj.type, uname: obj.uname, pwd: obj.pwd}
			this.setData(bwts);			
		}

		this.removeUser = function(userId){
			var bwts = this.getData();
			delete bwts["users"][userId];
			this.setData(bwts);
		}

		this.setData = function(bwtsObj){
			localStorage.setItem("bwts", JSON.stringify(bwtsObj));
		}

		this.getData = function(){
			return JSON.parse(localStorage.getItem("bwts"));
		}

		this.checkUserAvailability = function(obj){
			var bwts = this.getData(), users = bwts["users"]
			for(var c in users){
				if(users["uname"] === obj.email && users["pwd"] === obj.pwd){
					this.setLoggedInUserId(c);
					return true;
				}
			}
			return false;
		}

		this.checkLoginCredentials = function(obj){
				var bwts = this.getData(), userDet;
				
				if(obj.selectedType == "admin"){
					userDet = bwts["users"]["1"];
					this.setLoggedInUserId("1");
				}else{
				 	userDet = this.checkUserAvailability(obj);
				}

				if(userDet && userDet["uname"] === obj.email && userDet["pwd"] === obj.pwd){
					return true;
				}
				return false
		}

})

.controller("mainCtrl", function(localStorageSvc, $scope){
	if(localStorageSvc.getData() == null){
		localStorageSvc.setAdminData();
	}

	$scope.logout = function(){

	}
})

.controller("loginCtrl", function(localStorageSvc, $scope, $location){
	$scope.login = {};
	$scope.userTypes = ["Select User Type", "admin", "product", "support"];
	$scope.login.selectedType = $scope.userTypes[0];
	$scope.formSubmit = function(){
		console.log($scope.login);
		if(localStorageSvc.checkLoginCredentials($scope.login)){
			$location.path($scope.login.selectedType == "admin" ? "/admin" : "/user");
		}else{
			alert("Enter correct credentials and try again !");
		}
	}
})


.controller("adminCtrl", function(localStorageSvc, $scope){
	console.log(localStorageSvc.getLoggedInUserId());
})

.controller("userCtrl", function(localStorageSvc, $scope){

})

.controller("logoutCtrl", function(localStorageSvc, $scope){

})
